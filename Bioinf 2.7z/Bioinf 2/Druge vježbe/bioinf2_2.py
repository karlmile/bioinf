import math
import random

def realizirajVekt(V):
    for i in range(len(V)):
        V[i]=float(V[i])
    return V

def realiziraj(M):
    m=len(M)
    n=len(M[0])
    for i in range(m):
        for j in range(n):
            M[i][j]=float(M[i][j])
    return M

def logaritmirajMatr(M):
    for i in range(len(M)):
        for j in range(len(M[i])):
            M[i][j]=math.log(M[i][j])
    return M

def logaritmirajVekt(M):
    for i in range(len(M)):
        M[i]=math.log(M[i])
    return M


#VIPA
def vipa(me,mt,x):
    ml=len(me) ## model length, i.e. the no of states
    sl=len(x) ### sequence length
    tmp=[]
    for i in range(sl):
        tmp.append(20)
    visc=[] ### viterbi score matrix
    vpth=[] ### viterbi path matrix
    for i in range(ml):
        visc.append(tmp[:])
        vpth.append(tmp[:])
    ### boundary
    for i in range(ml):
        visc[i][0]= me[i][int(x[0])]
    ### loop
    for i in range(1,sl):
        for j in range(ml):
            visc[j][i]=me[j][int(x[i])]+ mt[0][j]+visc[0][i-1]
            vpth[j][i]=0
            for k in range(ml):
                a=me[j][int(x[i])]+ mt[k][j]+visc[k][i-1]
                if a>visc[j][i]:
                    visc[j][i]=a
                    vpth[j][i]=k

    op=[] ### our path
    tmpv=visc[0][sl-1]
    tmpp=0
    for k in range(ml):
        if visc[k][sl-1]>tmpv:
            tmpv=visc[k][sl-1]
            tmpp=k
    op.append(tmpp)
    for i in range(sl-1, 0, -1):
        a=vpth[tmpp][i]
        op.append(a)
        tmpp=a
    op.reverse()
    return [visc, vpth, op]

##FORWARD algoritam

def normMatr(M):
    for i in range(len(M)):
        suma=sum(M[i])
        for j in range(len(M[i])):
            M[i][j]=M[i][j]/suma
    return M


def iterativnikorak(simboli,stanja,brStanja,brIshoda):
    me=[]
    mt=[]
    for i in range(brStanja):
        row=[]
        for j in range(brStanja):
            row.append(1)
        mt.append(row)
    for i in range(brStanja):
        row=[]
        for j in range(brIshoda):
            row.append(1)
        me.append(row)

    #računamo emisijske vjerojatnosti
    for t in range(len(simboli)):
        me[int(stanja[t])][int(simboli[t])]+=1        

    for t in range(1,len(simboli)):
        mt[int(stanja[t-1])][int(stanja[t])]+=1
    return [normMatr(me),normMatr(mt)]



#ucitavam matricu emisijskih vjerojatnosti E
##f=open("C:\\Users\\Josip\\Documents\\Bioinformatika\\Bioinf 2\\Prve vježbe\\kocke_e.txt", "r")
##lines=f.readlines()
##E=[]
##for line in lines:
##    values=line.split()
##    E.append(values[:])
##f.close()
##E=realiziraj(E)

E=[[0.16,0.16,0.16,0.16,0.16,0.2],[0.2,0.16,0.16,0.16,0.16,0.16],[0.16,0.2,0.16,0.16,0.16,0.16]]


#ucitavam matricu tranzicijskih vjerojatnosti A
##f=open("C:\\Users\\Josip\\Documents\\Bioinformatika\\Bioinf 2\\Prve vježbe\\kocke_t.txt", "r")
##lines=f.readlines()
##A=[]
##for line in lines:
##    values=line.split()
##    A.append(values[:])
##if A[-1] == []:
##    A = A[:-1]
##f.close()
##A=realiziraj(A)

A=[[8./21,6./21,7./21],[7./21,8./21,6./21],[6./21,7./21,8./21]]

#ucitavamo niz opazenih vrijednosti X
f=open("C:\\Users\\Josip\\Documents\\Bioinformatika\\Bioinf 2\\Druge vježbe\\uzorak.txt", "r")
X=f.read().splitlines()
X=realizirajVekt(X)



for i in range(10):
    E,A=iterativnikorak(X,vipa(logaritmirajMatr(E),logaritmirajMatr(A),X)[2],3,6)

print(E)
print("\n")
print(A)
print("\n")


import math

#radimo viterbijev algoritam
def viterbi(E, A, X, P=0):
    K=len(A)                #broj skrivenih stanja
    n=len(X)                #duljina niza

    V=[]
    for i in range(K):
        row=[]
        for j in range(n):
            row.append(0)
        V.append(row)
    Vput=[]
    for i in range(K):
        row=[]
        for j in range(n):
            row.append(0)
        Vput.append(row)
        
    #prvi stupac dobivamo ovisno o početnoj distribuciji ja pretpostavjam uniformnu
    if P==0:
        for i in range(K):
            V[i][0]=(1/K)*E[i][int(X[0])-1]

    else:
        for i in range(K):
            V[i][0]=P[i]*E[i][int(X[0])-1]
    #popunjavamo ostale stupce
    for i in range(1, n):
        for j in range(K):
            m=0
            Vput[j][i]=0
            for k in range(K):
                tmp=E[j][int(X[i])-1]*A[k][j]*V[k][i-1]
                if m < tmp:
                    m=tmp
                    V[j][i]=m
                    Vput[j][i]=k

    #sada radimo put
    put=[]
    tmp1=V[0][n-1]
    p=0
    for i in range(K): #nademo najvecu vrijednost u zadnjem stupcu 
        if V[i][n-1]>tmp1:
            tmp1=V[k][n-1]
            p=k
    put.append(p)
    for i in range(n-1, 0, -1):
        a=Vput[p][i]
        put.append(a)
        p=a
    put.reverse()

    return put

def realiziraj(M):
    m=len(M)
    n=len(M[0])
    for i in range(m):
        for j in range(n):
            M[i][j]=float(M[i][j])
    return M


#ucitavam matricu emisijskih vjerojatnosti E
f=open("C:\\Users\\Josip\\Documents\\Bioinformatika\\Bioinf 2\\Prve vježbe\\kocke_e.txt", "r")
lines=f.readlines()
E=[]
for line in lines:
    values=line.split()
    E.append(values[:])
f.close()
E=realiziraj(E)

#ucitavam matricu tranzicijskih vjerojatnosti A
f=open("C:\\Users\\Josip\\Documents\\Bioinformatika\\Bioinf 2\\Prve vježbe\\kocke_t.txt", "r")
lines=f.readlines()
A=[]
for line in lines:
    values=line.split()
    A.append(values[:])
if A[-1] == []:
    A = A[:-1]
f.close()
A=realiziraj(A)

#ucitavamo niz opazenih vrijednosti X
X="123455666666123452"
X = [int(x) for x in X]

#ucitavanje pocetne distribucije
pocetna=[0.1,0.9]

put1=viterbi(E,A,X)
print(put1)


####Goldstein kod
import math
import random

def logaritmirajMatr(M):
    for i in range(len(M)):
        for j in range(len(M[i])):
            if M[i][j]==0:
                M[i][j]=-500000
            else:
                M[i][j]=math.log(M[i][j])
    return M

def logaritmirajVekt(M):
    for i in range(len(M)):
        if M[i]==0:
            M[i]=-500000
        else:
            M[i]=math.log(M[i])
    return M


#VIPA
def vipa(me,mt,x):
    ml=len(me) ## model length, i.e. the no of states
    sl=len(x) ### sequence length
    tmp=[]
    for i in range(sl):
        tmp.append(20)
    visc=[] ### viterbi score matrix
    vpth=[] ### viterbi path matrix
    for i in range(ml):
        visc.append(tmp[:])
        vpth.append(tmp[:])
    ### boundary
    for i in range(ml):
        visc[i][0]= me[i][int(x[0])]
    ### loop
    for i in range(1,sl):
        for j in range(ml):
            visc[j][i]=me[j][int(x[i])-1]+ mt[0][j]+visc[0][i-1]
            vpth[j][i]=0
            for k in range(ml):
                a=me[j][int(x[i])-1]+ mt[k][j]+visc[k][i-1]
                if a>visc[j][i]:
                    visc[j][i]=a
                    vpth[j][i]=k

    op=[] ### our path
    tmpv=visc[0][sl-1]
    tmpp=0
    for k in range(ml):
        if visc[k][sl-1]>tmpv:
            tmpv=visc[k][sl-1]
            tmpp=k
    op.append(tmpp)
    for i in range(sl-1, 0, -1):
        a=vpth[tmpp][i]
        op.append(a)
        tmpp=a
    op.reverse()
    return [visc, vpth, op]

print(vipa(logaritmirajMatr(E),logaritmirajMatr(A),X)[2])
